package questao2;

public interface StringValidador {
	public String validarSobrenome(String sobrenome);
}
