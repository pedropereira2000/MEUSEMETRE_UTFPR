package mock;

public interface Logger {
	public boolean logTransformation(String originalMessage, String modifiedMessage);
}
