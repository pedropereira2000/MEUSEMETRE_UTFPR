package exemplo1;

import java.util.ArrayList;

public interface RHService {
	public ArrayList<Pessoa> getAllPessoas();
}
