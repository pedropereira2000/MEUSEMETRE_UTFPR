package turma;

public interface TurmaDAO {
	public boolean existe(Turma turma);

	public boolean salvar(Turma turma);
}
