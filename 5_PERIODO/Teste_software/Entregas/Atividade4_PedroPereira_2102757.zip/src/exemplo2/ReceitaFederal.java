package exemplo2;

public interface ReceitaFederal {
	public boolean isCPFBloqueado(String cpf);
}
