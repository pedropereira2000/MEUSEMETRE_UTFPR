package Exercicio12;

public interface CustoDAO {
	public int getCustoPorGrama(String regiao);
}
