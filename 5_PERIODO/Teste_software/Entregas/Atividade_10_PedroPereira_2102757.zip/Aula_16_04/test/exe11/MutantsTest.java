package exe11;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MutantsTest {

	@Test
	void testM1() {
		Original o = new Original();
		assertEquals(1, o.contarA("tempestAde"));
		
		Mutante1 logan = new Mutante1();
		assertEquals(1, logan.contarA("tempestAde"));
	}

	@Test
	void testM2() {
		Original o = new Original();
		assertEquals(1, o.contarA("tempestAde"));
		
		Mutante2 xavier = new Mutante2();
		assertEquals(1, xavier.contarA("tempestAde"));
		
		// mutante equivalente pois a express�o contador++ e contador=contador+1 s�o semanticamente equivalentes
	}
	
	@Test
	void testM3() {
		Original o = new Original();
		assertEquals(1, o.contarA("mistica"));
		
		Mutante3 fera = new Mutante3();
		assertEquals(1, fera.contarA("mistica"));
	}
	
}
