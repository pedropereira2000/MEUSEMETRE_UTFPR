package exe07;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import exe07.Original;
import exe07.Mutante1;

class MutantsTest {

	@Test
	void testM1() {
		Original o = new Original();
		int vet[] = new int[4];
		vet[0] = 22;
		vet[1] = 5;
		vet[2] = 31;
		vet[3] = 2;
		assertEquals(31, o.getMaior(vet));
		
		Mutante1 m1 = new Mutante1();
		assertEquals(31, m1.getMaior(vet));
	}
	
	@Test
	void testM2() {
		Original o = new Original();
		int vet[] = new int[4];
		vet[0] = 5;
		vet[1] = 22;
		vet[2] = 15;
		vet[3] = 2;
		assertEquals(22, o.getMaior(vet));
		
		Mutante2 m2 = new Mutante2();
		assertEquals(22, m2.getMaior(vet));
	}

	@Test
	void testM3() {
		Original o = new Original();
		int vet[] = new int[4];
		vet[0] = 0;
		vet[1] = 22;
		vet[2] = 15;
		vet[3] = 2;
		assertEquals(22, o.getMaior(vet));
		
		Mutante3 m3 = new Mutante3();
		assertEquals(22, m3.getMaior(vet));
		
		// mutante equivalente pois come�ar a verifica��o de maior pela primeira posi��o 
		//n�o altera o valor final, pois o la�o come�a com o maior recebendo o valor da primeira posi��o
	}
	
}
