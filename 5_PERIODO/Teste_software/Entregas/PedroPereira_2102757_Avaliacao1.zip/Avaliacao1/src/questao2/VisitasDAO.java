package questao2;

public interface VisitasDAO {
	public int incrementarVisitasPara(String endereco);
}
