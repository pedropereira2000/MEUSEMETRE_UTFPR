package questao2;

public class Dono {
	private int id;
	private String sobrenome;
	
	public Dono(int id, String sobrenome) {
		this.id = id;
		this.sobrenome = sobrenome;
	}
	
	public int getId() {
		return id;
	}
	
	public String getSobrenome() {
		return sobrenome;
	}
}
