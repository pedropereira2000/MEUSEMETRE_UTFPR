package Exercicio9;

public interface DescontoDAO {
	public int getDesconto(String tipoCli, boolean temCupom);
}
