package Exercicio9;

public class CalcularDesconto {
	private DescontoDAO descontoDao;
	
	public CalcularDesconto(DescontoDAO descontoDao) {
		this.descontoDao = descontoDao;
	}
	
	public int realizarCalculo(String tipoCli, boolean temCupom) {
		//continuacao do method
		return 0;
	}
}
