package Exercicio17;

public class Salario {
	int valorSalario;
	String pendencia;

	public String getPendencia() {
		return pendencia;
	}

	public int getValorSalario() {
		return valorSalario;
	}
}
