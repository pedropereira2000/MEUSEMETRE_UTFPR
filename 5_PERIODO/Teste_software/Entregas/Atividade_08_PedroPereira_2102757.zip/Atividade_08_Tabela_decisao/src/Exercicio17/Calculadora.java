package Exercicio17;

public class Calculadora {
	public Salario calcularSalario(String tipoEmpregado, int horasTrabalhadas) {        
		//todo        
		return null;    
	}
}
