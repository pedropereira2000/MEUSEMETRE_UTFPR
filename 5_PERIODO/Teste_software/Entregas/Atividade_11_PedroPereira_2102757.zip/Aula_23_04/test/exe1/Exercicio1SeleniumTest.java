package exe1;

import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class Exercicio1SeleniumTest {

	private static WebDriver d;
	//private static JavascriptExecutor js;
	
	@BeforeAll
	public static void beforeAll() {
		System.setProperty("webdriver.chrome.driver","C:\\\\Users\\\\user\\\\Documents\\\\Teste_software\\\\Aula_23_04\\\\lib\\\\chromedriver.exe");
		d = new ChromeDriver();
		d.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		d.manage().window().maximize();
		// apelar para o JS
		//js = (JavascrriptExecutor) d;
	}
	
	@BeforeEach
	public void beforeEach() {
		d.get("https://saucelabs.com/test/guinea-pig");
	}
	
	@AfterAll
	public static void afterAll() {
		//d.close();
	}
	
	@Test
	void testCenario01() {
		//Clicar no link dispon�vel na tela 
		d.findElement(By.xpath("//*[@id=\"i am a link\"]")).click();
				
		//verificar se foi adequadamente para a outra p�gina
		var div = d.findElement(By.xpath("//*[@id=\"i_am_an_id\"]"));
		
		assertEquals("I am another div", div.getText());
	}
	
	@Test
	void testCenario02() {
		//Preencher os inputs
		d.findElement(By.xpath("//*[@id=\"i_am_a_textbox\"]")).clear();
		d.findElement(By.xpath("//*[@id=\"i_am_a_textbox\"]")).sendKeys("T� testando");
		d.findElement(By.xpath("//*[@id=\"fbemail\"]")).sendKeys("Calmo j� testei");
		
		//Preencher o textArea
		d.findElement(By.xpath("//*[@id=\"comments\"]")).sendKeys("Tudo bom com voc� venho informar que essa parada de realizar a constru��o de testes"
				+" automatizados � muito loco e quero aprender mais");

		//Verificar se o checkbox est� marcado ou desmarcado
		var ch1 = d.findElement(By.xpath("//*[@id=\"unchecked_checkbox\"]")).isSelected();
		var ch2 = d.findElement(By.xpath("//*[@id=\"checked_checkbox\"]")).isSelected();
		assertFalse(ch1);
		assertTrue(ch2);
		
		//Marcar/desmarcar os checkboxes
		d.findElement(By.xpath("//*[@id=\"unchecked_checkbox\"]")).click();
		d.findElement(By.xpath("//*[@id=\"checked_checkbox\"]")).click();
		
		ch1 = d.findElement(By.xpath("//*[@id=\"unchecked_checkbox\"]")).isSelected();
		ch2 = d.findElement(By.xpath("//*[@id=\"checked_checkbox\"]")).isSelected();
		assertFalse(ch2);
		assertTrue(ch1);
	}
	
	@Test
	void testCenario03() {
		//Preencher o textArea com um coment�rio
		d.findElement(By.xpath("//*[@id=\"comments\"]")).sendKeys("Opa desculpe a intromiss�o mais � que eu tenho que preencher esse textarea"
				+" por motivo de teste para a mat�ria de teste de software");
		
		//Clicar no bot�o �send�
		d.findElement(By.xpath("//*[@id=\"submit\"]")).click();
		
		//Verificar se seus �comments� apareceram depois da frase �Your comments:�
		var comment = d.findElement(By.xpath("//*[@id=\"your_comments\"]")).getText();
		
		assertEquals("Your comments: Opa desculpe a intromiss�o mais � que eu tenho que preencher esse textarea por motivo de teste para a mat�ria de teste de software", comment);
	}

}
