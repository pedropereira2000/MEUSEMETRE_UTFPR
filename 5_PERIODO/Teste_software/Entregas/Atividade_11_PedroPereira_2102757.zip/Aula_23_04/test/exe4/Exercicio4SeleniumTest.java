package exe4;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

class Exercicio4SeleniumTest {

	private static WebDriver d;
	//private static JavascriptExecutor js;
	
	@BeforeAll
	public static void beforeAll() {
		System.setProperty("webdriver.chrome.driver","C:\\\\Users\\\\user\\\\Documents\\\\Teste_software\\\\Aula_23_04\\\\lib\\\\chromedriver.exe");
		d = new ChromeDriver();
		d.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		d.manage().window().maximize();
		// apelar para o JS
		//js = (JavascrriptExecutor) d;
	}
	
	
	@BeforeEach
	public void beforeEach() {
		d.get("https://andreendo.github.io/sample-ui-compras/example.html");
	}
	
	@AfterAll
	public static void afterAll() {
		d.close();
	}
	
	
	@Test
	void testCenario01() {
		d.findElement(By.name("produto")).sendKeys("Ma�a");
		d.findElement(By.name("quantidade")).sendKeys("3");
		d.findElement(By.xpath("//*[@id=\"root\"]/div/form/input")).click();
		d.findElement(By.xpath("//*[@id=\"root\"]/div/div/button")).click();
		
		var h1 = d.findElement(By.xpath("//h1"));
		
		assertEquals("Lista de compras", h1.getText());
		
		d.findElement(By.xpath("//*[@id=\"root\"]/div/button")).click();
		
		h1 = d.findElement(By.xpath("//h1"));
		
		assertEquals("Criar uma lista de compras", h1.getText());
	}
	
	@Test
	void testCenario02() {
		d.findElement(By.name("produto")).sendKeys("Ma�a");
		d.findElement(By.name("quantidade")).sendKeys("4");
		d.findElement(By.xpath("//*[@id=\"root\"]/div/form/input")).click();
		
		d.findElement(By.name("produto")).sendKeys("Banana");
		d.findElement(By.name("quantidade")).sendKeys("3");
		d.findElement(By.xpath("//*[@id=\"root\"]/div/form/input")).click();
		
		d.findElement(By.name("produto")).sendKeys("Arroz");
		d.findElement(By.name("quantidade")).sendKeys("2");
		d.findElement(By.xpath("//*[@id=\"root\"]/div/form/input")).click();
		
		d.findElement(By.name("produto")).sendKeys("Feij�o");
		d.findElement(By.name("quantidade")).sendKeys("1");
		d.findElement(By.xpath("//*[@id=\"root\"]/div/form/input")).click();
		
		d.findElement(By.id("prod0")).click();
		d.findElement(By.id("prod2")).click();
		
		var items = d.findElements(By.xpath("//li"));
		
		assertEquals(2, items.size());
		assertTrue(items.get(0).getText().contains("Banana"));
		assertTrue(items.get(1).getText().contains("Arroz"));
	}
}


