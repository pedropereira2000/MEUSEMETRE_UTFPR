package atividade08;

import java.util.ArrayList;

public interface Dicionario {
	public ArrayList<String> getListaDeSenhasInvalidas();
}
