package atividade10;

public class BancoDeDados {
	private VerificadorDeCodigos verificador;

	public BancoDeDados(VerificadorDeCodigos verificador) {
		this.verificador = verificador;
	}

	public String cadastrarTurma(String codDisciplina, String codTurma, int numeroAlunos) {        
		//todo        
		return "";
	}
}
