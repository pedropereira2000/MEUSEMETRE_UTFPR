package atividade16;

public interface ClienteDAO {
	public boolean ehCliente(String nome);
}
