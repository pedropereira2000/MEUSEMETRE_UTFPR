package atividade16;

public class MontanhaRussaControlador {
	ClienteDAO clienteDao;

	public MontanhaRussaControlador(ClienteDAO pClienteDao) {
		clienteDao = pClienteDao;
	}

	public String autorizar(String nome, int idade) throws Exception {        
		//todo         
		return "";
	}
}
