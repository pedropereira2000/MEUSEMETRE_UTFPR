package exe3;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;

class DecisionMakerTest {

	@Test
	void testCT1() {
		//Usuario inativo por mais de 2 semanas
		var user = new Usuario(100,false,false);
		var decMak = new DecisionMaker();
		var res = decMak.mostrarAnuncio(user, false);
		
		assertFalse(res);
		
	}
	
	@Test
	void testCT2() {
		//Ativo nas duas ultimas semanas n�o viu anuncio e tem menos de 1000 seguidores
		var user = new Usuario(100,true,false);
		var decMak = new DecisionMaker();
		var res = decMak.mostrarAnuncio(user, false);
		
		assertTrue(res);
		
	}

	@Test
	void testCT3() {
		//Ativo nas duas ultimas semanas mas j� viu an�ncio e tem menos de 1000 seguidores
		var user = new Usuario(100,true,true);
		var decMak = new DecisionMaker();
		var res = decMak.mostrarAnuncio(user, false);
		
		assertFalse(res);
		
	}
	
	@Test
	void testCT4() {
		//tem mas de 1000 seguidores e o an�ncio n�o � relevante 
		var user = new Usuario(3000,true,true);
		var decMak = new DecisionMaker();
		var res = decMak.mostrarAnuncio(user, false);
		
		assertFalse(res);
		
	}
	
	@Test
	void testCT5() {
		//tem mas de 1000 seguidores e o an�ncio � relevante
		var user = new Usuario(2000,true,false);
		var decMak = new DecisionMaker();
		var res = decMak.mostrarAnuncio(user, true);
		
		assertTrue(res);
		
	}
	
}
