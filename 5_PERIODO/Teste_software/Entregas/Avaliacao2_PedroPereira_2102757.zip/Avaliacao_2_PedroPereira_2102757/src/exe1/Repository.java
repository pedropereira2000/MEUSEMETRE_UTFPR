package exe1;

public interface Repository {
	boolean orderProduct(int prodId);
}
