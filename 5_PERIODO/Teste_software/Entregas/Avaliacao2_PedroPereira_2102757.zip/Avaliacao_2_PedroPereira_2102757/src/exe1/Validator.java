package exe1;

import java.util.List;

public interface Validator {
	public List<String> validateBasicData(Order customer);
}
