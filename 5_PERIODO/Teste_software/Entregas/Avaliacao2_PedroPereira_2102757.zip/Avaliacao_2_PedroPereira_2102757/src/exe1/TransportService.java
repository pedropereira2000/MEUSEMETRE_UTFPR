package exe1;

public interface TransportService {
	public boolean isDown();

	public int makeTag(int code, String address);

}
