package exe3;

public class DecisionMaker {
	public boolean mostrarAnuncio(Usuario u, boolean anuncioRelevante) {
		// TODO
		return false;
	}
}
