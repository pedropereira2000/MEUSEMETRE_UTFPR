package exe2;

public class VerificadorEleitoral {
	private CartorioEleitoral cartorioEleitoral;

	public VerificadorEleitoral(CartorioEleitoral cartorioEleitoral) {
		this.cartorioEleitoral = cartorioEleitoral;
	}

	public String consultarSituacao(int idade, String cpf) throws Exception {
		// todo
		return "";
	}

}
