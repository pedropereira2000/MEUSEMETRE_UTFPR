package exe03;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import exe03.MaquinaCafe;

class MaquinaCafeTest {

	@Test
	void testPedirCafeEmTodosOsEstados() throws Exception{
		//new(),
		var maquina = new MaquinaCafe();
		
		//pedirCafe() / false,
		assertFalse(maquina.pedirCafe());
		
		//adicionarMoeda (1)
		maquina.adicionarMoeda(1);
		
		//pedirCafe() / false
		assertFalse(maquina.pedirCafe());
		
		//adicionarMoeda (1)
		maquina.adicionarMoeda(1);
		
		//pedirCafe() / true
		assertTrue(maquina.pedirCafe());
		
		//pedirCafe() / false
		assertFalse(maquina.pedirCafe());
	}
	
	@Test
	void testTransicoesNaoCobertasAnteriormente() throws Exception{
		//new
		var maquina = new MaquinaCafe();
		
		//adicionarMoeda(!=1) / Exception
		assertThrows(Exception.class, () -> maquina.adicionarMoeda(2));
		
		//adicionarMoeda(1)
		maquina.adicionarMoeda(1);
		
		//adicionarMoeda(!=1) / Exception
		assertThrows(Exception.class, () -> maquina.adicionarMoeda(2));
		
		//adicionarMoeda(1)
		maquina.adicionarMoeda(1);
		
		//adicionarMoeda(!=1) / Exception
		assertThrows(Exception.class, () -> maquina.adicionarMoeda(2));
		
		//adicionarMoeda(1) / Exception
		assertThrows(Exception.class, () -> maquina.adicionarMoeda(1));
	}

}
