package exe05;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ClimatizadorTest {

	@Test
	void testUmidificador() {
		//new
		var c = new Climatizador();
		//ligar
		c.ligar();
		//umidificar
		c.umidificar();
		//umidificando/false
		assertFalse(c.umidificando());
		//umidificar
		c.umidificar();
		assertTrue(c.umidificando());
		//aumentarV/true
		assertTrue(c.aumentarV());
		//umidicar
		c.umidificar();
		//umidificando/false
		assertFalse(c.umidificando());
		//umidificar
		c.umidificar();
		//umidificando/true
		assertTrue(c.umidificando());
	}
	
	@Test
	void testDesligar() {
		//new
		var c = new Climatizador();
		//ligar
		c.ligar();
		//desligar
		c.desligar();
		//ligar
		c.ligar();
		//umidificando/true
		assertTrue(c.umidificando());
		//aumentarV
		assertTrue(c.aumentarV());
		//Umidificar
		c.umidificar();
		//umidificando/false
		assertFalse(c.umidificando());
		//desligar
		c.desligar();
		
	}
	
	@Test
	void testTransicoesQueNaoForamCobertas() {
		//new
		var c = new Climatizador();
		//desligar / Exception
		assertThrows(Exception.class, () -> c.desligar());
		//ligar
		c.ligar();
		//ligar / Exception
		assertThrows(Exception.class, () -> c.ligar());
		//umidificar
		c.umidificar();
		//diminuirV / Exception
		assertFalse(c.diminuirV());
		//umidificar
		c.umidificar();
		//aumentarV
		c.aumentarV();
		//aumentarV / false
		assertFalse(c.aumentarV());
		//umidificar
		c.umidificar();
		//aumentarV / false
		assertFalse(c.aumentarV());
		//umidificando / false
		assertFalse(c.umidificando());
		//desligar
		c.desligar();
		
	}

}
